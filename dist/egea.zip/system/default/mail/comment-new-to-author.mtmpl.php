<?= $content['comment-text'] ?> 
	<?= $content['commenter'] ?> <<?= $content['commenter-email'] ?>>
	<?= _S ('em--reply') ?>: <?= $content['reply-href'] ?> 

<?= $content['comment-href'] ?> 


<?= _S ('em--created-automatically') ?>