<?php if (array_key_exists ('form', $content)) { ?>
<?= _T_FOR ($content['form']) ?>
<?php } ?>  
