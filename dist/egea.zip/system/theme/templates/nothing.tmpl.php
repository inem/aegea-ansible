<?php if (@$content['nothing']) { ?> 
<p><?=@$content['nothing']?></p>
<?php } ?>
