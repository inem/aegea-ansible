<form
  action="<?= @$content['form-sessions']['form-action'] ?>"
  method="post"
>

<button type="submit" id="submit-button" class="button">
  <?= @$content['form-sessions']['submit-text'] ?>
</button>

</form>

<p></p>
