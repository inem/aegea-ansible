<?php return array (

  'display_name' => array (
    'en' => 'System',
    'ru' => 'Системная',
  ),

); ?>