<?php return array (

  'display_name' => array (
    'en' => 'Plain',
    'ru' => 'Простая',
  ),

); ?>